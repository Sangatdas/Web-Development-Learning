<?php

    $salt = "isefjfehi2736582KUFED";

    echo md5($salt."password");

?>