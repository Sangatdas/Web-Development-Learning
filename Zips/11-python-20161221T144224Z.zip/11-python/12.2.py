#! /usr/bin/python

print 'Content-type: text/html'
print ''
print 'Hello world'