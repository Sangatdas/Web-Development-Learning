<?php

    include("includedfile.php");
    
    echo file_get_contents("https://www.ecowebhosting.co.uk");

?>